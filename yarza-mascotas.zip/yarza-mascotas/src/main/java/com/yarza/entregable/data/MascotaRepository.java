package com.yarza.entregable.data;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.yarza.entregable.model.Mascota;

public interface MascotaRepository extends PagingAndSortingRepository<Mascota, Long> {

}
