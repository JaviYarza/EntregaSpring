package com.yarza.entregable;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YarzaMascotasApplication {

	public static void main(String[] args) {
		SpringApplication.run(YarzaMascotasApplication.class, args);
	}

}
