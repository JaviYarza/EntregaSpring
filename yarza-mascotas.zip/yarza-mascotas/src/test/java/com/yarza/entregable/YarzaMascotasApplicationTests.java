package com.yarza.entregable;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YarzaMascotasApplicationTests {

	@Test
	void contextLoads() {
	}

}
